# HackCU52019
Twitter API project

NOTE: 'twitterStats2019.py' is the BACKEND implementation of our program. To use the program with frontend integration, follow the instructions below:

Instructions to run:
  Navigate to the TwitterUserStats folder
  Ensure that the two main librarys: Flask and Tweedy are installed. We have included a .zip file of the files. You can also use the command $pip install {library name} to install the files as well.
  Once the files are installed go to the directory of the python file.
  Run the python file using the command python appDriver.py
  This command should pop up a https address in the terminal. Copy and paste that https address into a browser.
  This process will take you to our website and user interface.


How to use once running:
  give the program any valid twitter handle. Wait for the program to load, then you can explore the different menues included. Different menues will display various statistics on this users profile.
